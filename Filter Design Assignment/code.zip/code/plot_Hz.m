function [] = plot_Hz(H_z)
[h,w]=freqz(cell2mat(H_z.num),cell2mat(H_z.den),10000);
plot(w,abs(h)/max(abs(h)));
end
